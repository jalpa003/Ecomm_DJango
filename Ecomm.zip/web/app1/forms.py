from django import forms 
from .models import profile
from .models import ShippingAddress

# creating a form
 
# class InputForm(forms.Form): 
  
 #   mobile_num = forms.IntegerField( help_text = "Enter 10 digit mobile number" ) 
  #  alternate_mobile_num  = forms.IntegerField( help_text = "confirm mobile number" ) 
   # address = forms.CharField(max_length = 200) 
    #City = forms.CharField(max_length = 50) 
    #State = forms.CharField(max_length = 50) 
    #Zipcode = forms.IntegerField()
    #Country = forms.CharField(max_length = 50) 


  
# create a ModelForm 
class InputForm(forms.ModelForm): 
    # specify the name of model to use 
    class Meta: 
        model = profile 
        fields = "__all__"
