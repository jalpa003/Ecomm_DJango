from django.shortcuts import render
from app1.models import webuser
from app1.models import products
from app1.models import profile
from app1.models import ShippingAddress
from django.views.generic import FormView
from django.shortcuts import render 
from .forms import InputForm 
from django import forms


# Create your views here.
def login(request):
	return render(request,"login.html")
def logincheck(request):
	uname = request.GET.get("uname")
	upass = request.GET.get("upass")
	list1 = webuser.objects.all()
	dict1 = {'webuser':list1}
	print(list1)
	for i in list1:
		if(i.uname==uname and i.upass==upass):
			request.session['uname']=uname
			return render(request,'home.html')
def home(request):
	return render(request,"home.html")
def userprofile(request):
	l1 = profile.objects.filter()
	#l1 = profile.objects.select_related()
	#item = webuser.objects.get(pk=1)  # This is the `Purchase_Items` instance
	#purchase = item.user_id  # This is the `Purchases` instance
	dict1 = {'profile':l1}

	l2 = ShippingAddress.objects.all()
	dict2 = {'ShippingAddress':l2}
	return render(request,"userprofile.html",dict1)
def cart(request):
	return render(request,'cart.html')
def category(request):
	return render(request,"category.html")
def contact(request):
	return render(request,'contact.html')
#def profile_view(request): 
#    context ={} 
#    context['form']= InputForm() 
#    return render(request, "profile.html", context) 
def profile_view(request): 
    context ={} 
  
    # create object of form 
    form = InputForm(request.POST or None, request.FILES or None) 
      
    # check if form data is valid 
    if form.is_valid(): 
        # save the form data to model 
        form.save() 
  
    context['form']= form 
    return render(request, "profile.html", context) 