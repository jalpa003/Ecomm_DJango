from django.contrib import admin
from app1.models import webuser
from app1.models import products
from app1.models import profile
from app1.models import ShippingAddress


# Register your models here.
admin.site.register(webuser)
admin.site.register(products)
admin.site.register(ShippingAddress)
admin.site.register(profile)

