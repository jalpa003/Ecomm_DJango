from django.db import models


# Create your models here.
class webuser(models.Model):
	uname = models.CharField(max_length=15)
	upass = models.CharField(max_length=10)
	def __str__(self):
		return(self.uname)
class products(models.Model):
	pname = models.CharField(max_length=100)
	price = models.IntegerField()
	quantity = models.IntegerField()
	Category = models.CharField(max_length=50)
	Availibility = models.CharField(max_length=30)
	Description = models.CharField(max_length=100)
	Image = models.ImageField(upload_to='img', blank=True)
	def __str__(self):
		return(self.pname)
class profile(models.Model):
	user_id = models.ForeignKey(webuser, on_delete=models.CASCADE)
	mobile_num = models.IntegerField()
	alternate_mobile_num = models.IntegerField()
	address = models.ManyToManyField('ShippingAddress')
	
class ShippingAddress(models.Model):
	Address_line1 = models.CharField(max_length=20)
	Address_line2 = models.CharField(max_length=20)
	City = models.CharField(max_length=15)
	State = models.CharField(max_length=15)
	Zipcode = models.IntegerField() 
	Country = models.CharField(max_length=15)
	def __str__(self):
		return(self.Address_line1)


